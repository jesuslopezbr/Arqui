Proyecto realizado por Matthew Moorcroft Jesus Lopez Baeza-Rojano
y Alvaro Varela Cacharro

Compilacion:
1. gcc -o practica1 main.c
2. gcc -o prog1 prog1.c -lm

Usage:
- ./nombre_programa <path_texto> <path_programa>
